package com.usian.service;

import com.usian.pojo.OrderInFo;

public interface OrderService {
    String insertOrder(OrderInFo orderInFo);
}
